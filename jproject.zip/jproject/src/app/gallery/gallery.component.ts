import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {

  constructor() { }

  // rate=14;
  // value1:any="";
  imgDefault = 'imgChange';



categories = ['Trans','Col','Business']



  changeImage(option: string){

if(option == "Trans"){

    this.imgDefault = 'imgChange';

    console.log("this.imgDefault :",this.imgDefault);

}

 else if(option == "Col"){

    this.imgDefault = 'imgChange1';

      console.log("this.imgDefault :",this.imgDefault);

}

else if(option == "Business"){

    this.imgDefault = 'imgChange2';

      console.log("this.imgDefault :",this.imgDefault);

}

}

ngOnInit(): void {
}
}
